# todo-js

A simple todo app based on the principles of GTD and PARA using basic js html and css.

This project will use

- date-fns
- localStorage

## Brain storming

- clone the access app
